package p12_database;

import p12_database.ui.FrmLogin;

public class MemberManagement {

  public static void main(String[] args) {
    new FrmLogin("Welcom Login",270,200);
  }
}
